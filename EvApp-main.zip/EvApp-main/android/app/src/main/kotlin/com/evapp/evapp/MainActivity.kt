package com.evapp.evapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
