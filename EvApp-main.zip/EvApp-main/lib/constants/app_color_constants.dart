import 'package:flutter/material.dart';

class AppColorConstants {
  static const Color grey = Color(0xFFF1F1F1);
  static const Color white = Color(0xFFFFFFFF);
  static const Color orange = Color(0xFFFFA726);
  static const Color red = Color(0xFFE57373);
}
